//
//  AQIViewController.swift
//  TIMHackaton
//
//  Created by Giovanni Erpete on 05/07/2020.
//  Copyright © 2020 Giovanni Erpete. All rights reserved.
//

import UIKit
import MapKit

class AQIViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var aqiLevel: UILabel!
    @IBOutlet weak var no2Level: UILabel!
    @IBOutlet weak var co2Level: UILabel!
    @IBOutlet weak var so2Level: UILabel!
    @IBOutlet weak var pm2_5: UILabel!
    @IBOutlet weak var pm5Level: UILabel!
    @IBOutlet weak var pm10Level: UILabel!
    let locationManager = CLLocationManager()
    let apiManager = APIManager.getSingleton()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self

        // Do any additional setup after loading the view.
        
        var city = ""
        geocode(latitude: locationManager.location!.coordinate.latitude, longitude: locationManager.location!.coordinate.longitude, completion: {placemarks, errors in
            print("[Geocode] \(placemarks?.first?.locality ?? "")")
            city = placemarks?.first?.locality ?? ""
        })
        
        self.apiManager.getData(latitude: locationManager.location!.coordinate.latitude, longitude: locationManager.location!.coordinate.longitude)
        
        aqiLevel.text = "AQI Level: \(apiManager.airQualityData?.iqaValue ?? "NO DATA")"
        no2Level.text = apiManager.airQualityData?.pollutants?.no2 ?? "NO VALUE"
        co2Level.text = apiManager.airQualityData?.pollutants?.co ?? "NO VALUE"
        so2Level.text = apiManager.airQualityData?.pollutants?.so2 ?? "NO VALUE"
        pm2_5.text = apiManager.airQualityData?.pollutants?.pm1 ?? "NO VALUE"
        pm5Level.text = apiManager.airQualityData?.pollutants?.pm2_5 ?? "NO VALUE"
        pm10Level.text = apiManager.airQualityData?.pollutants?.pm10 ?? "NO VALUE"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func pressed(_ sender: Any) {
        
        self.dismiss(animated: true) {
            
            print("ADDIO")
            
        }
    }
    
    func geocode(latitude: Double, longitude: Double, completion: @escaping (_ placemark: [CLPlacemark]?, _ error: Error?) -> Void)  {
        CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: latitude, longitude: longitude)) { placemark, error in
            guard let placemark = placemark, error == nil else {
                completion(nil, error)
                return
            }
            completion(placemark, nil)
        }
    }
    
}
