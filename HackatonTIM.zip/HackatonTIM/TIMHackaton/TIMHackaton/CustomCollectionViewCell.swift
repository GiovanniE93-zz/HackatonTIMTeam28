//
//  CustomCollectionViewCell.swift
//  TIMHackaton
//
//  Created by Giovanni Erpete on 05/07/2020.
//  Copyright © 2020 Giovanni Erpete. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var myLabel: UILabel!
    
}
