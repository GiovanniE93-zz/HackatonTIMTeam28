//
//  PanModal.h
//  PanModal
//
//  Created by Tosin A on 3/13/19.
//  Copyright © 2019 Detail. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PanModal.
FOUNDATION_EXPORT double PanModalVersionNumber;

//! Project version string for PanModal.
FOUNDATION_EXPORT const unsigned char PanModalVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PanModal/PublicHeader.h>


